I added Screen Space Ambient Occlusion,
In the ImGui panel there is a render target viewer, as well as a SSAO settings menu that can adjust the samples and the radius of the SSAO post process.